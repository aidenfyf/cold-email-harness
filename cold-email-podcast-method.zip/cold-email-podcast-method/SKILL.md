---
name: cold-email-podcast-method
description: "Generate cold email variants for podcast guest outreach campaigns using the Podcast Method. Use this skill whenever the user asks to create cold email variants, generate outreach emails, build podcast invite sequences, write cold emails for any niche or industry, or mentions Instantly, cold outreach, podcast method, guest invitations, or email campaigns. Also trigger when the user says 'create variants for [niche]', 'generate emails for [industry]', 'cold email for [vertical]', or any variation of requesting outreach copy for a podcast-style campaign. This skill produces 10 data-backed email variants ready for deployment into Instantly or any cold email platform."
---

# Cold Email Generation - Podcast Method

## Overview

This skill generates 10 cold email variants for podcast guest outreach campaigns. It works across any niche or industry. The output is formatted for direct deployment into Instantly or any cold email sequencing tool.

The system is built on two layers: Podcast method frameworks (8 battle-tested structural templates + 2 data-derived frameworks) and a Campaign DNA constraint layer extracted from a real campaign that hit 14.63% Positive Reply Rate across 3,780 contacts.

## How To Use

When triggered, follow these steps in exact order. Do not skip steps. Do not start writing emails before completing Steps 1 and 2.

### Collect Inputs

Before doing anything, confirm you have these four inputs from the user. If any are missing, ask before proceeding:

1. **NICHE** - the industry or vertical (e.g. "HVAC contractors", "SaaS founders", "wealth managers")
2. **COUNTRY** - the target country
3. **CLIENT NAME** - the client's full name (first + last)
4. **COMPANY NAME** - the client's company name

### Step 1: Niche Research

Search the web for real, current information about this niche. Run multiple searches covering industry forums, subreddits, LinkedIn posts, recent articles, and real podcast episodes featuring guests in this niche.

Output four sections:

**A) TONE PROFILE** - 3-4 sentences on how people in this niche communicate. Formal vs informal, direct vs relationship-first, sceptical vs open, what they hate reading. This informs word choice and register across all 10 variants.

**B) TRUST SIGNALS** - What makes a podcast invite credible to someone in this niche? What would make them delete it? Be specific to the niche.

**C) PODCAST NAME GUIDANCE** - What kind of podcast name would land? What tone feels right? What would feel off?

**D) LIVE TOPICS** - 5-6 episode topics grounded in what's actually being discussed right now. Format: short title (3-6 words) + one sentence on why it's relevant. Must come from real sources.

### Step 2: Pre-Write Checkpoint

Before writing a single email, confirm:

- **Podcast name:** State the name you'll use across all variants and why it fits
- **Tone calibration:** How should the tone profile affect the copy? Blunt niches get shorter, plainer copy. Relationship-driven niches get slightly warmer.
- **Topic selection:** Pick 1-2 topics from LIVE TOPICS for customisation slots
- **Trust signal check:** Confirm none of the 10 templates trigger scepticism flags

### Step 3: Apply Campaign DNA Constraints

Read `/mnt/skills/user/cold-email-podcast-method/references/campaign-dna.md` before generating any variants. These constraints are non-negotiable and apply to every variant.

### Step 4: Generate 10 Variants

Read `/mnt/skills/user/cold-email-podcast-method/references/frameworks.md` for the 10 base scripts, subject line assignments, output format rules, signature rules, and adaptation instructions. Generate exactly 10 variants, one per framework.

### Step 5: Quality Check

Run every variant against these checks before outputting:

- **Reply test:** Would a real founder in this niche reply? Not a generic founder - someone who gets 50 cold emails a week.
- **Colleague test:** Does this read like a friend dashing off a note, or a template?
- **Tone calibration check:** Does the copy reflect the tone profile?
- **Customisation check:** Are filled slots natural or forced? Forced is worse than empty.
- **CLIENT NAME check:** First name only in body, EXCEPT after "hosted by" or "our host and founder" (full name).
- **Signature check:** Each variant uses its correct signature exactly.
- **Campaign DNA check:** Run against the constraint layer. Verify sentence count, opening line rules, CTA validity, banned phrases, word count.
- **Em dash check:** Scan entire output. Zero tolerance for em dashes ( — ). Use hyphens ( - ) or rewrite.

## Critical Rules

- NEVER use em dashes ( — ) anywhere in the output. Avoid hyphens with spaces ( - ) as well. Instead, rewrite and prioritize sentence variation.
- NEVER replace `{{variables}}` with actual values: `{{firstName}}`, `{{companyName}}`, `{{sendingAccountName}}`, `{{sendingAccountFirstName}}`, `{{industry}}`
- NEVER replace `{{industry}}` with the actual niche name
- NEVER use the word "fluff"
- NEVER use "in addition" or "furthermore"
- NEVER use "genuinely", "honestly", or "straightforward"
- Use ellipses (...) for casual pacing only when appropriate
- Use CLIENT NAME's first name only in email body, full name after "hosted by" or "our host and founder" and in signatures

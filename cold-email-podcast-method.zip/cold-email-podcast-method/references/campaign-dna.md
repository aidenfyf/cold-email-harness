# Campaign DNA Constraints

These rules are extracted from a real cold email campaign that hit 4.63% Positive Reply Rate across 3,780 contacts (2.3x above the 2% benchmark). Every rule traces back to a specific variant's performance data. Treat these as hard constraints during generation.

---

## Email Length

- 3 to 5 sentences max in the main body. Every extra sentence reduces PRR.
- The highest-converting variant (38.89% book rate) was 4 sentences.
- If it can't be said in 5 sentences, cut until it can.

## Opening Line Rules

- Never open with "I" unless it's "I host [podcast name]" or "I work with [name]"
- Never open with a question
- Never open with "We'd love to invite you" as the very first words (repositioning later in body is acceptable in frameworks that use it)
- Best openers by PRR: action statement ("We're producing..."), anti-pattern statement ("We're not looking for a polished speaker..."), third-party referral ("[Name] found you on LinkedIn...")
- Drop into the pitch within the first sentence. No warming up.

## CTA Rules (Ranked by Book Rate)

1. "Open to a conversation?" - lowest friction, highest book rate
2. "Would you be open to joining us as a guest?" - slightly more formal, still effective
3. "Would you want to come on and answer it?" - works for question-hook framework
4. "Would you be open to a quick interview?" - acceptable, slightly lower conversion

NEVER use:
- "Any interest?" - too vague, 0% book rate in testing
- "Would you be open to joining us for an interview?" - "interview" tested 14% lower than "conversation" on book rate

One CTA per email. One is enough.

## Psychological Triggers (From Top Performers)

**Status elevation over flattery.** "We feature {{industry}} leaders" works. "Your incredible journey" does not. The prospect should feel selected, not flattered.

**Anti-polish framing.** "We're not looking for a polished speaker" was the #2 variant (5.03% PRR). It's a compliment disguised as a filter. The prospect qualifies because they're real, not rehearsed.

**Third-party referral framing.** The #1 variant (5.82% PRR) used "[Name] found you on LinkedIn." Breaks the cold email pattern entirely. The prospect feels recommended, not pitched.

**Brevity as authority.** Short emails attract decisive prospects. The shortest variant had the highest book rate (38.89%). Length signals uncertainty. Brevity signals confidence.

**Time objection pre-handling.** A PS line addressing time commitment ("if a full episode isn't the right fit right now, we also do shorter recorded segments") converts fence-sitters without weakening the main CTA.

## Kill Patterns (From Variants That Died)

- "We don't usually cold email" - 0.79% PRR, zero bookings. Apologising before you speak kills credibility.
- "Any interest?" as standalone CTA - vague, gives nothing to respond to
- Vague flattery without a specific reason for selection
- More than 2 questions in the email body
- Emails over 150 words
- Opening with the company name or offer description

## Banned Phrases

Never use in any variant:

- "Hope this finds you well"
- "Just wanted to reach out"
- "Touching base"
- "I think you'd be a great guest" (without a specific reason)
- "I'd love to pick your brain"
- "We'd love to feature your story" (without specificity)
- "Our listeners would love to hear from you"
- "This would be a great opportunity for exposure"
- "We're building something really exciting"
- "No strings attached"
- "Synergy" / "game-changer" / "scale your business"
- "Genuinely" / "honestly" / "straightforward"
- "In addition" / "furthermore"
- The word "fluff"

## Follow-Up (Step 2) Framework

- Wait 3 to 5 days after initial send
- Keep follow-up under 2 sentences
- Reference the original value prop, don't just say "following up"
- Best structure: "Hey {{firstName}}, [one-line callback to original pitch]. Still open?"
- Optional: add light scarcity ("locking in our next recording block") or social proof ("we've had [X] leaders confirm since I last reached out")
- Never use: "Just following up," "Bumping this," "Circling back"

## Testing Protocol

- Split evenly across variants (equal send volume per variant)
- Minimum 300 sends per variant for statistical significance
- Primary metric: Composite Score (PRR x Book Rate)
- Kill threshold: any variant below 2% PRR after 200 sends
- Promote threshold: any variant above 5% PRR after 200 sends gets doubled
- Review at 500 total sends, then again at 1,500, then at 3,000

# Base Frameworks (10 Variants)

## Fixed Assumptions

- Company size: 1-50 employees
- Audience: Founders, owners, or senior operators
- Podcast name: Generate a new podcast name each time that feels natural for the niche but isn't overly specific. Short (2-4 words), catchy, broad enough for adjacent spaces. Do NOT reuse across runs. Examples by niche:
  - SaaS / Tech: "The Build Phase," "Shipping & Scaling," "The Stack"
  - Healthcare: "The Practice Lab," "Better Outcomes," "The Growth Pulse"
  - Construction / Trades: "Ground Up," "The Build Out," "Behind The Build"
  - Financial Services: "Capital Moves," "The Growth Ledger," "The Upside"
  - E-commerce / DTC: "Brand to Scale," "The Margins," "The Checkout Line"
  - Legal: "Off The Record," "The Firm Growth Show," "Behind Closed Doors"
  - Marketing / Agencies: "The Pipeline," "The Pitch Room," "Clicks to Clients"
  - Insurance: "Risk & Reward," "The Growth Lever," "The Trust Factor"
  - Real Estate: "Ground Level," "The Deal Room," "Built to Scale"
  - These are examples only - generate fresh each time
- All 10 variants use the `{{industry}}` variable - do NOT replace with actual niche name
- COMPANY NAME: Used only in Framework 2's signature ("Partner | [COMPANY NAME]")
- CLIENT NAME: first name only in body, EXCEPT after "hosted by" or "our host and founder" (full name). Full name in signatures and formal host introductions.
- No forwarded messages in any framework

---

## Adaptation Freedom (Tiered)

**LOCKED - never change:**
- The CTA in every framework
- The subject lines
- The `{{variables}}`: `{{firstName}}`, `{{companyName}}`, `{{sendingAccountName}}`, `{{sendingAccountFirstName}}`, `{{industry}}`
- The PS line in Framework 6
- The signature format for each framework

**FLEXIBLE - adapt to niche:**
- Customisation slots (guidance at each slot)
- Sentence-level phrasing where original wording feels off for the niche
- Tone and register (shorter/blunter for direct niches, warmer for relationship-driven)

**FREE - use judgement:**
- Any phrasing that sounds like marketing copy - simplify
- Contractions and casual language throughout
- The exact podcast name (matching pre-write checkpoint)

**Do NOT:**
- Merge scripts together
- Change CTAs
- Add new value propositions
- Add bullet points where none exist
- Replace `{{variables}}` with actual values
- Replace `{{industry}}` with the actual niche name

---

## Tone Rules

- Write like a colleague quickly firing off a message - not a sales rep
- Use natural contractions: we're, you're, it's, that's, don't, won't, there's, here's
- Avoid formal constructions: "we are," "you are," "it is," "would you like"
- Short sentences fine. Incomplete sentences fine if natural.
- If it sounds like a marketing brochure, cut or rewrite
- NEVER use em dashes ( — ). Use hyphens ( - ) or rewrite.

---

## What Bad Output Looks Like (Do NOT produce)

**Too formal:** "We would be truly honored to have you grace our podcast as a distinguished guest."

**Too salesy:** "This is an exclusive opportunity to amplify your brand visibility and position yourself as a thought leader."

**Too generic:** "We're reaching out to successful business leaders like yourself who are making waves in their industry."

**Over-flattery:** "Your incredible journey and awe-inspiring achievements make you the perfect candidate."

**Template voice:** "I came across your profile and was impressed by your work. I think you'd be a great fit for our show."

If output sounds like any of the above, rewrite until it sounds like a real person.

---

## Subject Line Assignments

| Framework | Subject Line |
| --------- | ------------ |
| 1 | Guest invitation for {{firstName}} |
| 2 | Podcast invite for {{firstName}} |
| 3 | podcast idea |
| 4 | invite for {{firstName}} |
| 5 | Guest invite |
| 6 | Guest spot |
| 7 | Guest spot - Podcast invite for {{firstName}} |
| 8 | {{firstName}} - podcast invite |
| 9 | quick question for {{firstName}} |
| 10 | {{firstName}} |

---

## Output Format (Strict)

For each of the 10 variants, output:

1. The subject line in plain text
2. One single markdown code block containing the ENTIRE email (greeting, body, CTA, closing, and signature)
3. Nothing related to the email outside the code block
4. No commentary between variants
5. NEVER use em dashes anywhere

**Signature spacing - no blank lines between signature lines:**

WRONG:
```
Thanks!

{{sendingAccountName}}

Producer & Co-Host
[PODCAST NAME]
```

RIGHT:
```
Thanks!
{{sendingAccountName}}
Producer & Co-Host
[PODCAST NAME]
```

---

## Replacement Rules

- Replace [CLIENT NAME] in body with first name only - EXCEPT after "hosted by" or "our host and founder" (full name)
- Replace [CLIENT NAME] in signatures with full name
- Replace [PODCAST NAME] with confirmed podcast name
- Replace [COMPANY NAME] with provided company name
- DO NOT replace any `{{variables}}`

Customisation slots: replace with something specific from research. If nothing fits naturally, remove the slot entirely rather than forcing it.

---

## The 10 Frameworks

### Framework 1

Hi {{firstName}},

We'd love to invite you as a guest on our podcast, [PODCAST NAME], hosted by our founder, [CLIENT FULL NAME].

We're looking to feature {{industry}} leaders who are open to sharing their journey, story, and mission.

[CUSTOMISATION SLOT - optional: one sentence referencing a specific topic or angle from LIVE TOPICS. Remove if nothing fits cleanly.]

We're excited to build something meaningful with inspiring leaders like yourself. We would be honored to feature you as a guest.

Would you be open to joining us for an interview?

Thanks!
{{sendingAccountName}}
Producer & Co-Host
[PODCAST NAME]

---

### Framework 2

Hi {{firstName}},

We'd love to invite you as a guest on our podcast, [PODCAST NAME], hosted by our founder, [CLIENT FULL NAME].

We're looking to feature {{industry}} leaders who are open to sharing their journey, story, and mission.

[CUSTOMISATION SLOT - optional: same as Framework 1. One sentence, niche-specific. Remove if forced.]

We're excited to build something meaningful with inspiring leaders like yourself. We would be honored to feature you as a guest.

Would you be open to joining us for an interview?

Thanks!
{{sendingAccountName}}
Partner | [COMPANY NAME]

---

### Framework 3

Hi {{firstName}},

Quick one, we'd love to have you on [PODCAST NAME] as a guest.

We feature {{industry}} leaders and [CLIENT FULL NAME], our host and founder, is a big fan of what you're building.

[CUSTOMISATION SLOT - optional: one short sentence referencing something the niche is building toward or dealing with. E.g. "Especially with everything happening around [topic]." Remove if forced.]

Open to a conversation?

Thanks,
{{sendingAccountFirstName}}
Producer & Co-Host
[PODCAST NAME]

---

### Framework 4

Hey {{firstName}},

[CLIENT FIRST NAME] is building something with [PODCAST NAME] and you're exactly the kind of {{industry}} leader we want on the show.

Open to a conversation?

Best regards,
{{sendingAccountName}}
Producer & Co-Host
[PODCAST NAME]

---

### Framework 5

Hey {{firstName}},

We're producing [PODCAST NAME] for an audience of {{industry}} professionals who want to hear from people actually in the trenches, not just keynote speakers.

[CLIENT FIRST NAME] hosts and we're looking for guests with a real story to tell.

[CUSTOMISATION SLOT - optional: one niche-specific line about what "a real story" looks like in this space. E.g. "The kind of story about [niche-specific challenge]." One sentence max. Remove if forced.]

Would you be open to a quick interview?

Best regards,
{{sendingAccountName}}
Producer & Co-Host
[PODCAST NAME]

---

### Framework 6

Hey {{firstName}},

[CLIENT FIRST NAME] hosts [PODCAST NAME], a podcast built around {{industry}} leaders who are willing to talk honestly about how they got there.

Would you be open to joining us as a guest?

Best regards,
{{sendingAccountName}}
Producer & Co-Host
[PODCAST NAME]

PS - if a full episode isn't the right fit right now, we also do shorter recorded segments for people who are short on time.

---

### Framework 7

Hey {{firstName}},

We're not looking for a polished speaker. We're looking for someone who's actually been through it in {{industry}} and doesn't mind talking about what that looked like.

[CLIENT FIRST NAME] hosts [PODCAST NAME] and I think you'd be a good fit.

Open to a conversation?

Best regards,
{{sendingAccountName}}
Producer & Co-Host
[PODCAST NAME]

---

### Framework 8

Hey {{firstName}},

[CUSTOMISATION SLOT - replace the default question below with a more specific, niche-relevant version from LIVE TOPICS if one fits. Should feel like something a curious host would genuinely ask. If the default works, keep it.]

Default: What do you think most people get wrong about {{industry}}?

Genuinely asking. We run a podcast called [PODCAST NAME] with [CLIENT FIRST NAME] and that's the kind of question we like to start with.

Would you want to come on and answer it?

Best regards,
{{sendingAccountName}}
Producer & Co-Host
[PODCAST NAME]

---

### Framework 9

Hey {{firstName}},

{{sendingAccountFirstName}} here, I work with [CLIENT FIRST NAME] on [PODCAST NAME].

Was doing research for our next recording block and your name came up when we were looking at {{industry}} leaders worth talking to.

[CUSTOMISATION SLOT - optional: one sentence naming something specific about their niche or the kind of work they'd be known for. Should feel like 5 minutes of LinkedIn research. E.g. "Especially given how [their company type] are navigating [niche-relevant challenge] right now." Remove if nothing fits naturally.]

Open to a conversation?

Best regards,
{{sendingAccountName}}
Producer & Co-Host
[PODCAST NAME]

---

### Framework 10

Hey {{firstName}},

[PODCAST NAME] features {{industry}} operators who've actually built something - not influencers, not consultants talking theory.

[CUSTOMISATION SLOT - optional: one short line that grounds this in the niche. Should feel like a qualification filter, not flattery. E.g. "People who've scaled past [relevant milestone] or figured out [niche-specific problem] the hard way." One sentence max. Remove if forced.]

[CLIENT FIRST NAME] hosts. We keep it tight - 10 minutes to see if it's a fit before anyone commits.

Open to a conversation?

Best regards,
{{sendingAccountName}}
Producer & Co-Host
[PODCAST NAME]
